
window.addEventListener('DOMContentLoaded', () => {

    /* ── Bootstrap ScrollSpy ── */
    const sideNav = document.body.querySelector('#sideNav');
    if (sideNav) {
        new bootstrap.ScrollSpy(document.body, { target: '#sideNav', offset: 74 });
    }

    /* ── Collapse mobile navbar on link click ── */
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    document.querySelectorAll('#navbarResponsive .nav-link').forEach(link => {
        link.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

    /* ── Typed.js — rotating job titles ── */
    const typedEl = document.getElementById('typed-text');
    if (typedEl && typeof Typed !== 'undefined') {
        new Typed('#typed-text', {
            strings: [
                'Software Engineer',
                'Power Platform Developer',
                'AI Solutions Architect',
                'Low-Code Innovation Expert',
                'Data &amp; Analytics Specialist'
            ],
            typeSpeed:  55,
            backSpeed:  30,
            backDelay:  2200,
            startDelay: 500,
            loop:       true,
            cursorChar: '|',
        });
    }

    /* ── Section reveal on scroll ── */
    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('section-visible');
            }
        });
    }, { threshold: 0.06 });

    document.querySelectorAll('section.resume-section').forEach(s => {
        sectionObserver.observe(s);
    });

    /* ── Card stagger reveal ── */
    const cardSelector =
        '#experience .d-flex.justify-content-between, ' +
        '#project .d-flex.justify-content-between, ' +
        '#education .d-flex.justify-content-between';

    const cardObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, i) => {
            if (entry.isIntersecting) {
                /* stagger each card by 80 ms */
                const delay = (i % 5) * 80;
                setTimeout(() => entry.target.classList.add('card-visible'), delay);
                cardObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll(cardSelector).forEach(c => cardObserver.observe(c));

    /* ── Back-to-top button ── */
    const backBtn = document.getElementById('backToTop');
    if (backBtn) {
        window.addEventListener('scroll', () => {
            backBtn.classList.toggle('visible', window.scrollY > 450);
        }, { passive: true });

        backBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

});

